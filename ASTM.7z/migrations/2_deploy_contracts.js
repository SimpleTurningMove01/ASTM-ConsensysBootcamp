var ClientInfo = artifacts.require("./ClientInfo.sol");
var Coursetro = artifacts.require("./Coursetro.sol");
var Adoption = artifacts.require("./Adoption");
var ClientReports = artifacts.require("./ClientReports");

module.exports = function(deployer) {
  deployer.deploy(ClientInfo);
  deployer.deploy(Coursetro);
  deployer.deploy(Adoption);
  deployer.deploy(ClientReports);
};
